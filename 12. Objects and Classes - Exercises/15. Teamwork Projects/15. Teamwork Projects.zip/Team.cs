﻿using System.Collections.Generic;

namespace _15.Teamwork_Projects
{
    public class Team
    {
        public string TeamName { get; set; }
        public List<string> TeamMembers { get; set; }
        public string Creator { get; set; } 
    }
}
